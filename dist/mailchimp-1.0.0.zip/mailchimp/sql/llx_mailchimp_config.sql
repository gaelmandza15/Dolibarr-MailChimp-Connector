-- Copyright (C) 2026 Gael <gael@example.com>
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program. If not, see <https://www.gnu.org/licenses/>.

--
-- Configuration globale du connecteur Mailchimp (une ligne par entite)
--

CREATE TABLE llx_mailchimp_config(
	rowid integer AUTO_INCREMENT PRIMARY KEY,
	entity integer DEFAULT 1 NOT NULL,
	apikey_enc text,								-- cle API chiffree (format iv:cipher, base64)
	datacenter varchar(16),							-- prefixe datacenter Mailchimp (us1, us21...)
	default_list_id varchar(32),					-- audience Mailchimp par defaut
	merge_fields_map text,							-- JSON de mapping merge fields (FNAME, LNAME, SOCIETE...)
	from_name varchar(128),							-- nom d'expediteur par defaut des campagnes
	reply_to varchar(128),							-- email de reponse par defaut
	webhook_secret varchar(64),						-- secret ajoute a l'URL du webhook public
	webhook_enabled smallint DEFAULT 0 NOT NULL,	-- webhook declare aupres de Mailchimp
	date_creation datetime,
	tms timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	fk_user_creat integer
) ENGINE=innodb;
